/* MEDITHINK — community.js (Fase 3). Se carga DESPUÉS de members.js.
   Comparte feed, chats, comunicados y chats privados entre miembros; sincroniza "leído / no leído". */
(function(){
  'use strict';
  const base=Storage.prototype.setItem;
  const rd=()=>{try{return JSON.parse(localStorage.getItem('mt')||'{}')}catch(e){return {}}};
  const jget=(k,d)=>{try{return JSON.parse(localStorage.getItem(k)||'')||d}catch(e){return d}};
  const isA=()=>typeof admin!=='undefined'&&admin;
  const parts=s=>JSON.stringify([s.feed,s.posts,s.notes,s.dm]);
  let busy=false,t=null,since=+(localStorage.getItem('mt_cs')||0),sent=jget('mt_dm_sent',{});
  window.__dmReads=window.__dmReads||{};

  async function sync(){
    if(busy)return;const s=rd(),m=(s.members||[]).find(x=>x.id===s.me),me=isA()?'admin':(m&&m.id);
    if(!me)return;
    const h={'Content-Type':'application/json'};
    if(isA()){const tok=await window.mtAdminToken();if(!tok)return;h.Authorization='Bearer '+tok}
    // Conversaciones abiertas desde el último envío → "leído".
    const seen=(jget('mt_dm_seen',{})[me])||{},reads={};
    Object.keys(seen).forEach(k=>{if(seen[k]>(sent[k]||0))reads[k]=1});
    const snap=parts(s);busy=true;let again=false;
    try{
      const r=await fetch('/api/community/sync',{method:'POST',headers:h,body:JSON.stringify({member:m&&{e:m.e,pw:m.pw},since,reads,state:{feed:s.feed||[],posts:s.posts||{},notes:s.notes||[],dm:s.dm||{}}})});
      if(!r.ok)return;const j=await r.json();
      if(parts(rd())!==snap){again=true;return}          // el usuario cambió algo mientras tanto: no pisar
      Object.keys(reads).forEach(k=>sent[k]=seen[k]);localStorage.setItem('mt_dm_sent',JSON.stringify(sent));
      since=j.now;localStorage.setItem('mt_cs',String(since));
      // Lecturas: de otros (para mostrar ✓✓) y propias en otros dispositivos.
      window.__dmReads=j.reads||{};
      const all=jget('mt_dm_seen',{}),mine=all[me]||{};let seenChanged=false;
      Object.keys(j.reads||{}).forEach(k=>{const v=j.reads[k][me];if(v&&v>(mine[k]||0)){mine[k]=v;sent[k]=v;seenChanged=true}});
      if(seenChanged){all[me]=mine;base.call(localStorage,'mt_dm_seen',JSON.stringify(all))}
      const before=parts(s)+JSON.stringify((s.members||[]).filter(x=>x.pub));
      s.feed=j.feed;s.posts=j.posts;s.dm=j.dm;s.notes=j.notes;
      if(!isA())s.members=(s.members||[]).filter(x=>!x.pub).concat(j.dir.map(d=>({id:d.id,n:d.n,photo:d.photo,pub:1})));
      const changed=before!==parts(s)+JSON.stringify((s.members||[]).filter(x=>x.pub))||seenChanged;
      base.call(localStorage,'mt',JSON.stringify(s));
      Object.assign(S,{feed:s.feed,posts:s.posts,notes:s.notes,dm:s.dm,members:s.members});
      const ae=document.activeElement;
      if(changed&&typeof render==='function'&&!(ae&&/INPUT|TEXTAREA|SELECT/.test(ae.tagName)))render();else annotate();
    }catch(e){}finally{busy=false;if(again)setTimeout(sync,400)}
  }

  /* ---------- ✓ Enviado / ✓✓ Leído bajo mis mensajes privados ---------- */
  const st=document.createElement('style');
  st.textContent='.dm-rd{display:block;font-size:11px;opacity:.7;text-align:right}.dm-rd.ok{color:#2ee59d;opacity:1}';
  document.head.appendChild(st);
  function annotate(){
    try{
      if(view!=='dm'||!dmTo)return;
      const me=dmSelf(),key=dmKey(me,dmTo),msgs=S.dm[key]||[],rd2=(window.__dmReads[key]||{})[dmTo]||0;
      document.querySelectorAll('#dm-msgs .dm-msg').forEach((el,i)=>{
        const x=msgs[i];if(!x||x.f!==me||el.querySelector('.dm-rd'))return;
        const sp=document.createElement('small');sp.className='dm-rd';
        if(!x._t){sp.textContent='… Enviando'}
        else if(rd2>=x._t){sp.className+=' ok';sp.textContent='✓✓ Leído'}
        else sp.textContent='✓ Enviado · No leído';
        el.appendChild(sp);
      });
    }catch(e){}
  }
  const origRender=window.render;
  if(typeof origRender==='function')window.render=function(){const r=origRender.apply(this,arguments);annotate();return r};

  Storage.prototype.setItem=function(k,v){
    base.apply(this,arguments);
    if(busy)return;
    if(k==='mt'){clearTimeout(t);t=setTimeout(sync,2000)}
    else if(k==='mt_dm_seen'){clearTimeout(t);t=setTimeout(sync,600)}
  };
  setInterval(()=>{if(!document.hidden)sync()},10000);setTimeout(sync,2000);
})();
