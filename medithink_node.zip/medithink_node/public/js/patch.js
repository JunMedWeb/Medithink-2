/* ============================================================
   MEDITHINK — patch.js
   Correcciones aditivas al núcleo original. Se carga ANTES de
   core.js porque el núcleo llama a estas funciones pero nunca
   las definía (unreadN() fallaba en cada render y notify() al
   publicar o comentar). No se modifica ningún comando original.
   ============================================================ */

/** Registra un aviso de comunidad (publicación, comentario o respuesta).
 *  Formato leído por notesView(): {k, by, aid, title, pid, ts} */
function notify(k, by, aid, title, pid){
  try{
    S.notifs = (S.notifs || []).concat({ k, by, aid, title, pid, ts: Date.now() });
    if (S.notifs.length > 200) S.notifs = S.notifs.slice(-200);
  }catch(e){}
}

/** Cantidad de avisos y comunicados no leídos (badge 🔔 del encabezado). */
function unreadN(){
  try{
    const me = typeof dmSelf === 'function' ? dmSelf() : null;
    const since = S.nRead || 0;
    const a = (S.notifs || []).filter(n => (n.ts || 0) > since && n.aid !== me).length;
    const b = Math.max(0, (S.notes || []).length - (S.seen || 0));
    return a + b;
  }catch(e){ return 0 }
}
